﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WindowsFormsApplicationgobang
{
    public partial class Form1 : Form
    {
        private static bool[,] isDraw = new bool[20, 20];//二维数组用于检验当前坐标是否放置了棋子
        private MouseEventArgs e;

        private static int ncount=1;
        //private static bool isBlackStoneWin=false;
        //private static int N = 1;
        private static bool isBlackStoneWin = false;
        private static bool isWhiteStoneWin = false;
        //黑棋
        private const int n = 32;
        private bool isPlayBlackStone;
        private static int nblackstone = 0;
        private static int bcount = 0;
        private BlackStone[] black=new BlackStone[n];
        private static bool[,] isBlackStone = new bool[20, 20];
        
        //白棋
        private bool isPlayWhiteStone;
        private static int nwhitestone = 0;
        private static int wcount = 0;
        private WhiteStone[] white = new WhiteStone[n];
        private static bool[,] isWhiteStone = new bool[20, 20];

        public Form1()
        {
            InitializeComponent();
            InitBlackStone();
            InitWhiteStone();
            labelBlack.BackColor = Color.Red;
            labelBlack.Text = "黑方下";
        }
        public void InitBlackStone()
        {
            isPlayBlackStone = false;
            for (int i = 0; i < n; i++)
            {
                black[i] = new BlackStone();
                black[i].X = -10;
                black[i].Y = -10;
            }
            for (int i = 0; i < 20; i++)
            {
                for (int j = 0; j < 20; j++)
                {
                    isDraw[i, j] = false;
                    isBlackStone[i, j] = false;
                }
            }
        }
        public void InitWhiteStone()
        {
            isPlayWhiteStone = false;
            for (int i = 0; i < n; i++)
            {
                white[i] = new WhiteStone();
                white[i].X = -10;
                white[i].Y = -10;
            }
            for (int i = 0; i < 20; i++)
            {
                for (int j = 0; j < 20; j++)
                {
                    isWhiteStone[i, j] = false;
                }
            }
        }
        public void PlayBlackStone(MouseEventArgs e)       
        {
            int x = panelGobang.ClientRectangle.X;
            int y = panelGobang.ClientRectangle.Y;
            int[] gobangX = new int[20];
            int[] gobangY = new int[20];
           
            for (int i = 0; i < 20; i++)
            {
                gobangX[i] = x + (i + 1) * 20;
            }
            for (int i = 0; i < 20; i++)
            {
                gobangY[i] = y + (i + 1) * 20;
            }
            for (int i = 0; i < 20; i++)
            {
                if ((e.X >= gobangX[i] - 10) && (e.X <= gobangX[i] + 10))
                {
                    for (int j = 0; j < 20; j++)
                    {
                        if ((e.Y >= gobangY[j] - 10) && (e.Y <= gobangY[j] + 10))
                        {
                            black[bcount].X = gobangX[i];
                            black[bcount].Y = gobangY[j];
                            isPlayBlackStone = true;
                            break;
                        }
                    }
                    break;
                }
            }
        }
        public void PlayWhiteStone(MouseEventArgs e)
        {
            int x = panelGobang.ClientRectangle.X;
            int y = panelGobang.ClientRectangle.Y;
            int[] gobangX = new int[20];
            int[] gobangY = new int[20];

            for (int i = 0; i < 20; i++)
            {
                gobangX[i] = x + (i + 1) * 20;
            }
            for (int i = 0; i < 20; i++)
            {
                gobangY[i] = y + (i + 1) * 20;
            }
            for (int i = 0; i < 20; i++)
            {
                if ((e.X >= gobangX[i] - 10) && (e.X <= gobangX[i] + 10))
                {
                    for (int j = 0; j < 20; j++)
                    {
                        if ((e.Y >= gobangY[j] - 10) && (e.Y <= gobangY[j] + 10))
                        {
                            white[wcount].X = gobangX[i];
                            white[wcount].Y = gobangY[j];
                            isPlayWhiteStone = true;
                            break;
                        }
                    }
                    break;
                }
            }
        }
        public bool IsBlackStoneWinSR()
        {
            int N = 1;
            int x1 = black[bcount].X - 20;
            int x2 = black[bcount].X + 20;
            int y1 = black[bcount].Y + 20;
            int y2 = black[bcount].Y - 20;
            while (x1 >= 20 && y1 <= 360)
            {
                if (N == 5)
                {
                    break;
                }
                if (isBlackStone[x1 / 20 - 1, y1 / 20 - 1] != false)
                {
                    N++;
                    x1 = x1 - 20;
                    y1 = y1 + 20;
                }
                else
                {
                    break;
                }
            }
            if (N < 5)
            {
                while (x2 <= 360 && y2 >= 20)
                {
                    if (N == 5)
                    {
                        break;
                    }
                    if (isBlackStone[x2 / 20 - 1, y2 / 20 - 1])
                    {
                        N++;
                        x2 = x2 + 20;
                        y2 = y2 - 20;
                    }
                    else
                    {
                        break;
                    }
                }
            }
            if (N == 5)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        public bool IsBlackStoneWinSL()
        {
            int N = 1;
            int x1 = black[bcount].X - 20;
            int x2 = black[bcount].X + 20;
            int y1 = black[bcount].Y - 20;
            int y2 = black[bcount].Y + 20;
            while (x1>=20&&y1 >= 20)
            {
                if (N == 5)
                {
                    break;
                }
                if (isBlackStone[x1 / 20 - 1, y1 / 20 - 1] != false)
                {
                    N++;
                    x1 = x1 - 20;
                    y1 = y1 - 20;
                }
                else
                {
                    break;
                }
            }
            if (N < 5)
            {
                while (x2<=360&&y2 <= 360)
                {
                    if (N == 5)
                    {
                        break;
                    }
                    if (isBlackStone[x2 / 20 - 1, y2 / 20 - 1])
                    {
                        N++;
                        x2 = x2 + 20;
                        y2 = y2 + 20;
                    }
                    else
                    {
                        break;
                    }
                }
            }
            if (N == 5)
            {
                return true;
            }
            else
            {
                return IsBlackStoneWinSR();
            }
        }
        public bool IsBlackStoneWinY()
        {
            int N = 1;
            int y1 = black[bcount].Y - 20;
            int y2 = black[bcount].Y + 20;
            while (y1 >= 20)
            {
                if (N == 5)
                {
                    break;
                }
                if (isBlackStone[black[bcount].X / 20 - 1, y1 / 20 - 1] != false)
                {
                    N++;
                    y1 = y1 - 20;
                }
                else
                {
                    break;
                }
            }
            if (N < 5)
            {
                while (y2 <= 360)
                {
                    if (N == 5)
                    {
                        break;
                    }
                    if (isBlackStone[black[bcount].X / 20 - 1, y2 / 20 - 1])
                    {
                        N++;
                        y2 = y2 + 20;
                    }
                    else
                    {
                        break;
                    }
                }
            }
            if (N == 5)
            {
                return true;
            }
            else
            {
                return IsBlackStoneWinSL();
            }
        }
        public bool IsBlackStoneWinX()
        {
            int N = 1;
            int x1 = black[bcount].X - 20;
            int x2 = black[bcount].X + 20;
            while (x1 >= 20)
            {
                if (N == 5)
                {
                    break;
                }
                if (isBlackStone[x1 / 20 - 1, black[bcount].Y / 20 - 1] != false)
                {
                    N++;
                    x1 = x1 - 20;
                }
                else
                {
                    break;
                }
            }
            if (N < 5)
            {
                while (x2 <= 360)
                {
                    if (N == 5)
                    {
                        break;
                    }
                    if (isBlackStone[x2 / 20 - 1, black[bcount].Y / 20 - 1])
                    {
                        N++;
                        x2 = x2 + 20;
                    }
                    else
                    {
                        break;
                    }
                }
            }
            if (N == 5)
            {
                return true;
            }
            else
            {
                return IsBlackStoneWinY();
            }
        }

        public bool IsWhiteStoneWinSR()
        {
            int N = 1;
            int x1 =white[wcount].X - 20;
            int x2 = white[wcount].X + 20;
            int y1 = white[wcount].Y + 20;
            int y2 = white[wcount].Y - 20;
            while (x1 >= 20 && y1 <= 360)
            {
                if (N == 5)
                {
                    break;
                }
                if (isWhiteStone[x1 / 20 - 1, y1 / 20 - 1] != false)
                {
                    N++;
                    x1 = x1 - 20;
                    y1 = y1 + 20;
                }
                else
                {
                    break;
                }
            }
            if (N < 5)
            {
                while (x2 <= 360 && y2 >= 20)
                {
                    if (N == 5)
                    {
                        break;
                    }
                    if (isWhiteStone[x2 / 20 - 1, y2 / 20 - 1])
                    {
                        N++;
                        x2 = x2 + 20;
                        y2 = y2 - 20;
                    }
                    else
                    {
                        break;
                    }
                }
            }
            if (N == 5)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        public bool IsWhiteStoneWinSL()
        {
            int N = 1;
            int x1 = white[wcount].X - 20;
            int x2 = white[wcount].X + 20;
            int y1 = white[wcount].Y - 20;
            int y2 = white[wcount].Y + 20;
            while (x1 >= 20 && y1 >= 20)
            {
                if (N == 5)
                {
                    break;
                }
                if (isWhiteStone[x1 / 20 - 1, y1 / 20 - 1] != false)
                {
                    N++;
                    x1 = x1 - 20;
                    y1 = y1 - 20;
                }
                else
                {
                    break;
                }
            }
            if (N < 5)
            {
                while (x2 <= 360 && y2 <= 360)
                {
                    if (N == 5)
                    {
                        break;
                    }
                    if (isWhiteStone[x2 / 20 - 1, y2 / 20 - 1])
                    {
                        N++;
                        x2 = x2 + 20;
                        y2 = y2 + 20;
                    }
                    else
                    {
                        break;
                    }
                }
            }
            if (N == 5)
            {
                return true;
            }
            else
            {
                return IsWhiteStoneWinSR();
            }
        }
        public bool IsWhiteStoneWinY()
        {
            int N = 1;
            int y1 = white[wcount].Y - 20;
            int y2 = white[wcount].Y + 20;
            while (y1 >= 20)
            {
                if (N == 5)
                {
                    break;
                }
                if (isWhiteStone[white[wcount].X / 20 - 1, y1 / 20 - 1] != false)
                {
                    N++;
                    y1 = y1 - 20;
                }
                else
                {
                    break;
                }
            }
            if (N < 5)
            {
                while (y2 <= 360)
                {
                    if (N == 5)
                    {
                        break;
                    }
                    if (isWhiteStone[white[wcount].X / 20 - 1, y2 / 20 - 1])
                    {
                        N++;
                        y2 = y2 + 20;
                    }
                    else
                    {
                        break;
                    }
                }
            }
            if (N == 5)
            {
                return true;
            }
            else
            {
                return IsWhiteStoneWinSL();
            }
        }
        public bool IsWhiteStoneWinX()
        {
            int N = 1;
            int x1 = white[wcount].X - 20;
            int x2 = white[wcount].X + 20;
            while (x1 >= 20)
            {
                if (N == 5)
                {
                    break;
                }
                if (isWhiteStone[x1 / 20 - 1, white[wcount].Y / 20 - 1] != false)
                {
                    N++;
                    x1 = x1 - 20;
                }
                else
                {
                    break;
                }
            }
            if (N < 5)
            {
                while (x2 <= 360)
                {
                    if (N == 5)
                    {
                        break;
                    }
                    if (isWhiteStone[x2 / 20 - 1, white[wcount].Y / 20 - 1])
                    {
                        N++;
                        x2 = x2 + 20;
                    }
                    else
                    {
                        break;
                    }
                }
            }
            if (N == 5)
            {
                return true;
            }
            else
            {
                return IsWhiteStoneWinY();
            }
        }

        public void RenewStone()
        {
            bcount = 0;
            nblackstone = 0;
            isPlayBlackStone = false;
            for (int i = 0; i < n; i++)
            {
                //black[i] = new BlackStone();
                black[i].X = -10;
                black[i].Y = -10;
                //white[i] = new WhiteStone();
                white[i].X = -10;
                white[i].Y = -10;
            }
            for (int i = 0; i < 20; i++)
            {
                for (int j = 0; j < 20; j++)
                {
                    isDraw[i, j] = false;
                    isBlackStone[i, j] = false;
                }
            }
            ncount = 1;
            wcount = 0;
            nwhitestone = 0;
            isPlayWhiteStone = false;
            for (int i = 0; i < 20; i++)
            {
                for (int j = 0; j < 20; j++)
                {
                    isWhiteStone[i, j] = false;
                }
            }
        }

        private void panelGobang_Paint(object sender, PaintEventArgs e)
        {
            int x = panelGobang.ClientRectangle.X;
            int y = panelGobang.ClientRectangle.Y;
            for (int i = 0; i < 22; i++)
            {
                e.Graphics.DrawLine(new Pen(new SolidBrush(Color.Black)), new Point(x, y + 20 * i), new Point(x + 400, y + 20 * i));
            }
            for (int i = 0; i < 22; i++)
            {
               e.Graphics.DrawLine(new Pen(new SolidBrush(Color.Black)), new Point(x + 20 * i, y), new Point(x + 20 * i, y + 400));
            }
            for (int i = 0; i < nblackstone; i++)
            {
               black[i].DrawBlackStone(e.Graphics);
            }
            for (int i = 0; i < nwhitestone; i++)
            {
                white[i].DrawWhiteStone(e.Graphics);
            }
            if (ncount % 2 != 0)
            {
                if (isBlackStoneWin == true)
                {
                    isBlackStoneWin = false;
                    labelBlack.Text = "黑方下";
                }
                if (isWhiteStoneWin == true)
                {
                    isWhiteStoneWin = false;
                    labelBlack.Text="黑方下";
                    labelWhite.Text = "";
                }
                if (isPlayBlackStone)
                {
                    if (!isDraw[(black[bcount].X) / 20 - 1, (black[bcount].Y) / 20 - 1])
                    {
                        black[bcount].DrawBlackStone(e.Graphics);
                        nblackstone = bcount + 1;
                        isPlayBlackStone = false;
                        isDraw[(black[bcount].X) / 20 - 1, (black[bcount].Y) / 20 - 1] = true;
                        isBlackStone[(black[bcount].X) / 20 - 1, (black[bcount].Y) / 20 - 1] = true;      
                        if (IsBlackStoneWinX() == true)
                        {
                            MessageBox.Show("黑方获胜");
                            label2.Text = DateTime.Now.ToString();
                           // RenewStone();
                            isBlackStoneWin = true;
                            //labelBlack.Text = "";
                            //labelWhite.Text = "白方下";
                            panelGobang.Invalidate();
                            return;
                        }
                        bcount++;
                        ncount++;
                        labelWhite.BackColor = Color.RoyalBlue;
                        labelWhite.Text = "白方下";
                        labelBlack.Text = "";
                    }
                }
            }
            else
            {
                if (isPlayWhiteStone)
                {
                    if (!isDraw[(white[wcount].X) / 20 - 1, (white[wcount].Y) / 20 - 1])
                    {
                        white[wcount].DrawWhiteStone(e.Graphics);
                        nwhitestone = wcount + 1;
                        isPlayWhiteStone = false;
                        isDraw[(white[wcount].X) / 20 - 1, (white[wcount].Y) / 20 - 1] = true;
                        isWhiteStone[(white[wcount].X) / 20 - 1, (white[wcount].Y) / 20 - 1] = true;
                        if (IsWhiteStoneWinX() == true)
                        {
                            MessageBox.Show("白方获胜");
                            label2.Text = DateTime.Now.ToString();
                           // RenewStone();
                            isWhiteStoneWin = true;
                            //labelBlack.Text = "";
                            //labelWhite.Text = "白方下";
                            panelGobang.Invalidate();
                            labelWhite.Text = "白方下";
                            return;
                        }
                        wcount++;
                        ncount++;
                        labelBlack.BackColor = Color.Red;
                        labelBlack.Text = "黑方下";
                        labelWhite.Text = "";
                    }
                }
            }
        }

        private void panelGobang_MouseClick(object sender, MouseEventArgs e)
        {
            if (ncount % 2 != 0)
            {
                if (bcount >= n)
                {
                    if (wcount == n)
                    {
                        MessageBox.Show("您的棋子己用完!");
                        isPlayBlackStone = false;
                        return;
                    }
                }
                this.e = e;
                PlayBlackStone(e);
                panelGobang.Invalidate();
            }
            else
            {
                if (wcount >= n)
                {
                    MessageBox.Show("您的棋子己用完!");
                    isPlayWhiteStone = false;
                    return;
                }
                this.e = e;
                PlayWhiteStone(e);
                panelGobang.Invalidate();
            }
        }
        int i = 0;
        int w = Screen.PrimaryScreen.Bounds.Width;
        int h = Screen.PrimaryScreen.Bounds.Height;
        private void save_Click(object sender, EventArgs e)
        {
            label2.Text = DateTime.Now.ToString();
            i += 1;
            Bitmap bit1 = new Bitmap(this.Width, this.Height);
            this.DrawToBitmap(bit1, new Rectangle(0, 0, this.Width, this.Height));
            int border = (this.Width - this.ClientSize.Width) / 2;//边框宽度
            int caption = (this.Height - this.ClientSize.Height) - border;//标题栏高度
            Bitmap bit2 = bit1.Clone(new Rectangle(border, caption, this.ClientSize.Width, this.ClientSize.Height), System.Drawing.Imaging.PixelFormat.Format24bppRgb);
            bit1.Save("C:\\Users\\q\\Desktop\\截图小王子\\比赛结果" + i + ".jpg", System.Drawing.Imaging.ImageFormat.Jpeg);//包括标题栏和边框
           // bit2.Save("D:\\BBB.jpg", System.Drawing.Imaging.ImageFormat.Jpeg);//不包括标题栏和边框
            bit1.Dispose();
           // bit2.Dispose();
        

        }

        private void look_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start("C:\\Users\\q\\Desktop\\截图小王子");
            TopMost = false;
            this.Cursor = Cursors.Default;
        }

        private void label1_Click(object sender, EventArgs e)
        {
            
           

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            label1.Text = DateTime.Now.ToString();
        }

        private void again_Click(object sender, EventArgs e)
        {
            label1.Text = DateTime.Now.ToString();
            RenewStone();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

       
    }
}
