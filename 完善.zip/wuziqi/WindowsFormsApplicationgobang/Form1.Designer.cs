﻿namespace WindowsFormsApplicationgobang
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.labelBlack = new System.Windows.Forms.Label();
            this.labelWhite = new System.Windows.Forms.Label();
            this.save = new System.Windows.Forms.Button();
            this.look = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.again = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.panelGobang = new WindowsFormsApplicationgobang.panel1();
            this.SuspendLayout();
            // 
            // labelBlack
            // 
            this.labelBlack.AutoSize = true;
            this.labelBlack.Location = new System.Drawing.Point(76, 21);
            this.labelBlack.Name = "labelBlack";
            this.labelBlack.Size = new System.Drawing.Size(0, 12);
            this.labelBlack.TabIndex = 1;
            // 
            // labelWhite
            // 
            this.labelWhite.AutoSize = true;
            this.labelWhite.Location = new System.Drawing.Point(438, 21);
            this.labelWhite.Name = "labelWhite";
            this.labelWhite.Size = new System.Drawing.Size(0, 12);
            this.labelWhite.TabIndex = 2;
            // 
            // save
            // 
            this.save.Location = new System.Drawing.Point(466, 111);
            this.save.Name = "save";
            this.save.Size = new System.Drawing.Size(75, 23);
            this.save.TabIndex = 4;
            this.save.Text = "保存结果";
            this.save.UseVisualStyleBackColor = true;
            this.save.Click += new System.EventHandler(this.save_Click);
            // 
            // look
            // 
            this.look.Location = new System.Drawing.Point(466, 164);
            this.look.Name = "look";
            this.look.Size = new System.Drawing.Size(75, 23);
            this.look.TabIndex = 5;
            this.look.Text = "观看结果";
            this.look.UseVisualStyleBackColor = true;
            this.look.Click += new System.EventHandler(this.look_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(429, 228);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(41, 12);
            this.label1.TabIndex = 6;
            this.label1.Text = "label1";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // again
            // 
            this.again.Location = new System.Drawing.Point(466, 61);
            this.again.Name = "again";
            this.again.Size = new System.Drawing.Size(75, 23);
            this.again.TabIndex = 7;
            this.again.Text = "再来一局";
            this.again.UseVisualStyleBackColor = true;
            this.again.Click += new System.EventHandler(this.again_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(429, 281);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(0, 12);
            this.label2.TabIndex = 8;
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(417, 206);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(53, 12);
            this.label3.TabIndex = 9;
            this.label3.Text = "开始时间";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(419, 258);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(53, 12);
            this.label4.TabIndex = 10;
            this.label4.Text = "结束时间";
            // 
            // panelGobang
            // 
            this.panelGobang.BackColor = System.Drawing.SystemColors.Info;
            this.panelGobang.Location = new System.Drawing.Point(12, 43);
            this.panelGobang.Name = "panelGobang";
            this.panelGobang.Size = new System.Drawing.Size(401, 401);
            this.panelGobang.TabIndex = 3;
            this.panelGobang.Paint += new System.Windows.Forms.PaintEventHandler(this.panelGobang_Paint);
            this.panelGobang.MouseClick += new System.Windows.Forms.MouseEventHandler(this.panelGobang_MouseClick);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(566, 456);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.again);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.look);
            this.Controls.Add(this.save);
            this.Controls.Add(this.panelGobang);
            this.Controls.Add(this.labelWhite);
            this.Controls.Add(this.labelBlack);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.Name = "Form1";
            this.Text = "五子棋";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label labelBlack;
        private System.Windows.Forms.Label labelWhite;
        private panel1 panelGobang;
        private System.Windows.Forms.Button save;
        private System.Windows.Forms.Button look;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button again;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
    }
}

