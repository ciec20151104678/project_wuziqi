﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Drawing;

namespace WindowsFormsApplicationgobang
{
    class WhiteStone
    {
        public int X
        {
            set;
            get;
        }
        public int Y
        {
            set;
            get;
        }
        public void DrawWhiteStone(Graphics g)
        {
            using (SolidBrush brush = new SolidBrush(Color.Silver))
            {
                g.FillEllipse(brush, X - 10, Y - 10, 20, 20);
            }
        }
    }
}
