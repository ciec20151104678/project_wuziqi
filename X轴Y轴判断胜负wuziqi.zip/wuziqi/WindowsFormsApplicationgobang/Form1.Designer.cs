﻿namespace WindowsFormsApplicationgobang
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.labelBlack = new System.Windows.Forms.Label();
            this.labelWhite = new System.Windows.Forms.Label();
            this.panelGobang = new WindowsFormsApplicationgobang.panel1();
            this.SuspendLayout();
            // 
            // labelBlack
            // 
            this.labelBlack.AutoSize = true;
            this.labelBlack.Location = new System.Drawing.Point(76, 21);
            this.labelBlack.Name = "labelBlack";
            this.labelBlack.Size = new System.Drawing.Size(0, 12);
            this.labelBlack.TabIndex = 1;
            // 
            // labelWhite
            // 
            this.labelWhite.AutoSize = true;
            this.labelWhite.Location = new System.Drawing.Point(438, 21);
            this.labelWhite.Name = "labelWhite";
            this.labelWhite.Size = new System.Drawing.Size(0, 12);
            this.labelWhite.TabIndex = 2;
            // 
            // panelGobang
            // 
            this.panelGobang.BackColor = System.Drawing.SystemColors.Info;
            this.panelGobang.Location = new System.Drawing.Point(78, 43);
            this.panelGobang.Name = "panelGobang";
            this.panelGobang.Size = new System.Drawing.Size(401, 401);
            this.panelGobang.TabIndex = 3;
            this.panelGobang.Paint += new System.Windows.Forms.PaintEventHandler(this.panelGobang_Paint);
            this.panelGobang.MouseClick += new System.Windows.Forms.MouseEventHandler(this.panelGobang_MouseClick);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(566, 456);
            this.Controls.Add(this.panelGobang);
            this.Controls.Add(this.labelWhite);
            this.Controls.Add(this.labelBlack);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.Name = "Form1";
            this.Text = "五子棋";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label labelBlack;
        private System.Windows.Forms.Label labelWhite;
        private panel1 panelGobang;
    }
}

