﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Project_wuziqi
{
    class Mainsize
    {
        //主框体大小
        public static int Wid { get { return 520; } }
        public static int Hei { get { return 460; } }
        //棋盘大小
        public static int CBWid { get { return 401; } }
        public static int CBHei { get { return 401; } }
        //棋盘宽度
        public static int CBGap { get { return 20; } }
        //棋子直径
        public static int ChessRadious { get { return 16; } }
    }
}
