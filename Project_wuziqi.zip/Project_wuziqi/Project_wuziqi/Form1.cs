﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;


namespace Project_wuziqi
{
    public partial class Form1 : Form
    {
        private static bool[,] isDraw = new bool[20, 20];//二维数组用于检验当前坐标是否放置了棋子
        private MouseEventArgs e;

     //   private static int ncount = 1;
        //private static bool isBlackStoneWin=false;
        //private static int N = 1;
     //   private static bool isBlackStoneWin = false;
     //   private static bool isWhiteStoneWin = false;
        //黑棋
        private const int n = 100;
     //   private bool isPlayBlackStone;
        private static int nblackstone = 0;
     //   private static int bcount = 0;
        private BlackStone[] black = new BlackStone[n];
        private static bool[,] isBlackStone = new bool[20, 20];

        //白棋
     //   private bool isPlayWhiteStone;
        private static int nwhitestone = 0;
     //   private static int wcount = 0;
        private WhiteStone[] white = new WhiteStone[n];
        private static bool[,] isWhiteStone = new bool[20, 20];
public Form1()
        {
            InitializeComponent();
            
        }
        

        private void pictureBox1_Click(object sender, EventArgs e)
        {

            
        }

        private void pictureBox1_Paint(object sender, PaintEventArgs e)
        {
            int x = pictureBox1.ClientRectangle.X;
            int y = pictureBox1.ClientRectangle.Y;
            for (int i = 0; i < 22; i++)
            {
                e.Graphics.DrawLine(new Pen(new SolidBrush(Color.Black)), new Point(x, y + 20 * i), new Point(x + 400, y + 20 * i));
            }
            for (int i = 0; i < 22; i++)
            {
                e.Graphics.DrawLine(new Pen(new SolidBrush(Color.Black)), new Point(x + 20 * i, y), new Point(x + 20 * i, y + 400));
            }
            for (int i = 0; i < nblackstone; i++)
            {
                black[i].DrawBlackStone(e.Graphics);
            }
            for (int i = 0; i < nwhitestone; i++)
            {
                white[i].DrawWhiteStone(e.Graphics);
            }
        }

        }
    }