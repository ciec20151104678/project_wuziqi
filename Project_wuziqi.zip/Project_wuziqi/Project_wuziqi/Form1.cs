﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;


namespace Project_wuziqi
{
    public partial class Form1 : Form
    {
        private static bool[,] isDraw = new bool[20, 20];//二维数组用于检验当前坐标是否放置了棋子
        private MouseEventArgs e;

        private static int ncount = 1;
        //private static bool isBlackStoneWin=false;
        //private static int N = 1;
        private static bool isBlackStoneWin = false;
        private static bool isWhiteStoneWin = false;
        //黑棋
        private const int n = 100;
        private bool isPlayBlackStone;
        private static int nblackstone = 0;
        private static int bcount = 0;
        private BlackStone[] black = new BlackStone[n];
        private static bool[,] isBlackStone = new bool[20, 20];

        //白棋
        private bool isPlayWhiteStone;
        private static int nwhitestone = 0;
        private static int wcount = 0;
        private WhiteStone[] white = new WhiteStone[n];
        private static bool[,] isWhiteStone = new bool[20, 20];
public Form1()
        {
            InitializeComponent();
            
        }
        

        private void pictureBox1_Click(object sender, EventArgs e)
        {   
        }
        public void InitBlackStone()//黑棋初始
        {
            isPlayBlackStone = false;
            for (int i = 0; i < n; i++)
            {
                black[i] = new BlackStone();
                black[i].X = -5;
                black[i].Y = -5;
            }
            for (int i = 0; i < 20; i++)
            {
                for (int j = 0; j < 20; j++)
                {
                    isDraw[i, j] = false;
                    isBlackStone[i, j] = false;
                }
            }
        }
        public void PlayBlackStone(MouseEventArgs e)
        {
            int x = pictureBox1.ClientRectangle.X;
            int y = pictureBox1.ClientRectangle.Y;
            int[] gobangX = new int[20];
            int[] gobangY = new int[20];

            for (int i = 0; i < 20; i++)
            {
                gobangX[i] = x + (i + 1) * 20;
            }
            for (int i = 0; i < 20; i++)
            {
                gobangY[i] = y + (i + 1) * 20;
            }
            for (int i = 0; i < 20; i++)
            {
                if ((e.X >= gobangX[i] - 10) && (e.X <= gobangX[i] + 10))
                {
                    for (int j = 0; j < 20; j++)
                    {
                        if ((e.Y >= gobangY[j] - 10) && (e.Y <= gobangY[j] + 10))
                        {
                            // black[bcount].X = gobangX[i];
                            // black[bcount].Y = gobangY[j];
                            isPlayBlackStone = true;
                            break;
                        }
                    }
                    break;
                }
            }
        }
                    public bool IsBlackStoneWinSR()
        {
            int N = 1;
            int x1 = black[bcount].X - 20;
            int x2 = black[bcount].X + 20;
            int y1 = black[bcount].Y + 20;
            int y2 = black[bcount].Y - 20;
            while (x1 >= 20 && y1 <= 360)
            {
                if (N == 5)
                {
                    break;
                }
                if (isBlackStone[x1 / 20 - 1, y1 / 20 - 1] != false)
                {
                    N++;
                    x1 = x1 - 20;
                    y1 = y1 + 20;
                }
                else
                {
                    break;
                }
            }
            if (N < 5)
            {
                while (x2 <= 360 && y2 >= 20)
                {
                    if (N == 5)
                    {
                        break;
                    }
                    if (isBlackStone[x2 / 20 - 1, y2 / 20 - 1])
                    {
                        N++;
                        x2 = x2 + 20;
                        y2 = y2 - 20;
                    }
                    else
                    {
                        break;
                    }
                }
            }
            if (N == 5)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        public bool IsBlackStoneWinSL()
        {
            int N = 1;
            int x1 = black[bcount].X - 20;
            int x2 = black[bcount].X + 20;
            int y1 = black[bcount].Y - 20;
            int y2 = black[bcount].Y + 20;
            while (x1>=20&&y1 >= 20)
            {
                if (N == 5)
                {
                    break;
                }
                if (isBlackStone[x1 / 20 - 1, y1 / 20 - 1] != false)
                {
                    N++;
                    x1 = x1 - 20;
                    y1 = y1 - 20;
                }
                else
                {
                    break;
                }
            }
            if (N < 5)
            {
                while (x2<=360&&y2 <= 360)
                {
                    if (N == 5)
                    {
                        break;
                    }
                    if (isBlackStone[x2 / 20 - 1, y2 / 20 - 1])
                    {
                        N++;
                        x2 = x2 + 20;
                        y2 = y2 + 20;
                    }
                    else
                    {
                        break;
                    }
                }
            }
            if (N == 5)
            {
                return true;
            }
            else
            {
                return IsBlackStoneWinSR();
            }
        }
        public bool IsBlackStoneWinY()
        {
            int N = 1;
            int y1 = black[bcount].Y - 20;
            int y2 = black[bcount].Y + 20;
            while (y1 >= 20)
            {
                if (N == 5)
                {
                    break;
                }
                if (isBlackStone[black[bcount].X / 20 - 1, y1 / 20 - 1] != false)
                {
                    N++;
                    y1 = y1 - 20;
                }
                else
                {
                    break;
                }
            }
            if (N < 5)
            {
                while (y2 <= 360)
                {
                    if (N == 5)
                    {
                        break;
                    }
                    if (isBlackStone[black[bcount].X / 20 - 1, y2 / 20 - 1])
                    {
                        N++;
                        y2 = y2 + 20;
                    }
                    else
                    {
                        break;
                    }
                }
            }
            if (N == 5)
            {
                return true;
            }
            else
            {
                return IsBlackStoneWinSL();
            }
        }
        public bool IsBlackStoneWinX()
        {
            int N = 1;
            int x1 = black[bcount].X - 20;
            int x2 = black[bcount].X + 20;
            while (x1 >= 20)
            {
                if (N == 5)
                {
                    break;
                }
                if (isBlackStone[x1 / 20 - 1, black[bcount].Y / 20 - 1] != false)
                {
                    N++;
                    x1 = x1 - 20;
                }
                else
                {
                    break;
                }
            }
            if (N < 5)
            {
                while (x2 <= 360)
                {
                    if (N == 5)
                    {
                        break;
                    }
                    if (isBlackStone[x2 / 20 - 1, black[bcount].Y / 20 - 1])
                    {
                        N++;
                        x2 = x2 + 20;
                    }
                    else
                    {
                        break;
                    }
                }
            }
            if (N == 5)
            {
                return true;
            }
            else
            {
                return IsBlackStoneWinY();
            }
     
        }
        public void RenewStone()
        {
            bcount = 0;
            nblackstone = 0;
            isPlayBlackStone = false;
            for (int i = 0; i < n; i++)
            {
                //black[i] = new BlackStone();
                black[i].X = -10;
                black[i].Y = -10;
                //white[i] = new WhiteStone();
                white[i].X = -10;
                white[i].Y = -10;
            }
            for (int i = 0; i < 20; i++)
            {
                for (int j = 0; j < 20; j++)
                {
                    isDraw[i, j] = false;
                    isBlackStone[i, j] = false;
                }
            }
            ncount = 1;
            wcount = 0;
            nwhitestone = 0;
            isPlayWhiteStone = false;
            for (int i = 0; i < 20; i++)
            {
                for (int j = 0; j < 20; j++)
                {
                    isWhiteStone[i, j] = false;
                }
            }
        }
        private void pictureBox1_Paint(object sender, PaintEventArgs e)//棋面绘制
        {
            int x = pictureBox1.ClientRectangle.X;
            int y = pictureBox1.ClientRectangle.Y;
            for (int i = 0; i < 22; i++)
            {
                e.Graphics.DrawLine(new Pen(new SolidBrush(Color.Black)), new Point(x, y + 20 * i), new Point(x + 400, y + 20 * i));
            }
            for (int i = 0; i < 22; i++)
            {
                e.Graphics.DrawLine(new Pen(new SolidBrush(Color.Black)), new Point(x + 20 * i, y), new Point(x + 20 * i, y + 400));
            }
            for (int i = 0; i < nblackstone; i++)
            {
                black[i].DrawBlackStone(e.Graphics);
            }
            for (int i = 0; i < nwhitestone; i++)
            {
                white[i].DrawWhiteStone(e.Graphics);
            }
            if (ncount % 2 != 0)
            {
                if (isBlackStoneWin == true)
                {
                    isBlackStoneWin = false;
                    //labelBlack.Text = "黑方下";
                }
                if (isWhiteStoneWin == true)
                {
                    isWhiteStoneWin = false;
                    //labelBlack.Text="黑方下";
                    //labelWhite.Text = "";
                }
                if (isPlayBlackStone)
                {
                    if (!isDraw[(black[bcount].X) / 20 - 1, (black[bcount].Y) / 20 - 1])
                    {
                        black[bcount].DrawBlackStone(e.Graphics);
                        nblackstone = bcount + 1;
                        isPlayBlackStone = false;
                        isDraw[(black[bcount].X) / 20 - 1, (black[bcount].Y) / 20 - 1] = true;
                        isBlackStone[(black[bcount].X) / 20 - 1, (black[bcount].Y) / 20 - 1] = true;      
                        if (IsBlackStoneWinX() == true)
                        {
                            MessageBox.Show("黑方获胜");
                            RenewStone();
                            isBlackStoneWin = true;
                            //labelBlack.Text = "";
                            //labelWhite.Text = "白方下";
                            pictureBox1.Invalidate();
                            return;
                        }
                        bcount++;
                        ncount++;
                        //labelWhite.BackColor = Color.Red;
                        //labelWhite.Text = "白方下";
                        //labelBlack.Text = "";
                    }
                }
            }
            else
            {
                if (isPlayWhiteStone)
                {
                    if (!isDraw[(white[wcount].X) / 20 - 1, (white[wcount].Y) / 20 - 1])
                    {
                        white[wcount].DrawWhiteStone(e.Graphics);
                        nwhitestone = wcount + 1;
                        isPlayWhiteStone = false;
                        isDraw[(white[wcount].X) / 20 - 1, (white[wcount].Y) / 20 - 1] = true;
                        isWhiteStone[(white[wcount].X) / 20 - 1, (white[wcount].Y) / 20 - 1] = true;
                        //if (IsWhiteStoneWinX() == true)
                        {
                            MessageBox.Show("白方获胜");
                            RenewStone();
                            isWhiteStoneWin = true;
                            //labelBlack.Text = "";
                            //labelWhite.Text = "白方下";
                            pictureBox1.Invalidate();
                            //labelWhite.Text = "白方下";
                            return;
                        }
                        wcount++;
                        ncount++;
                        //labelBlack.BackColor = Color.Red;
                        //labelBlack.Text = "黑方下";
                        //labelWhite.Text = "";
                    }
                }
            }
        }

        private void pictureBox1_MouseClick(object sender, MouseEventArgs e)
        {
             if (ncount % 2 != 0)
            {
                if (bcount >= n)
                {
                    if (wcount == n)
                    {
                        MessageBox.Show("您的棋子己用完!");
                        isPlayBlackStone = false;
                        return;
                    }
                }
                this.e = e;
                PlayBlackStone(e);
                pictureBox1.Invalidate();
            }
            else
            {
                if (wcount >= n)
                {
                    MessageBox.Show("您的棋子己用完!");
                //    isPlayWhiteStone = false;
                    return;
                }
                this.e = e;
               // PlayWhiteStone(e);
                pictureBox1.Invalidate();
            }
        
        }

        }
    }