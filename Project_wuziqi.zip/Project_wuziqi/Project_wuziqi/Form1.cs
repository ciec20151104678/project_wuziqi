﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;


namespace Project_wuziqi
{
    public partial class Form1 : Form
    {
        private static bool[,] isDraw = new bool[20, 20];//二维数组用于检验当前坐标是否放置了棋子
        private MouseEventArgs e;

        private static int ncount = 1;
        //private static bool isBlackStoneWin=false;
        //private static int N = 1;
     //   private static bool isBlackStoneWin = false;
     //   private static bool isWhiteStoneWin = false;
        //黑棋
        private const int n = 100;
        private bool isPlayBlackStone;
        private static int nblackstone = 0;
        private static int bcount = 0;
        private BlackStone[] black = new BlackStone[n];
        private static bool[,] isBlackStone = new bool[20, 20];

        //白棋
        private bool isPlayWhiteStone;
        private static int nwhitestone = 0;
        private static int wcount = 0;
        private WhiteStone[] white = new WhiteStone[n];
        private static bool[,] isWhiteStone = new bool[20, 20];
        public Form1()
        {
            InitializeComponent();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {


        }
    }
}